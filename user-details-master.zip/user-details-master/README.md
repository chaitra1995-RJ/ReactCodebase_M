
# user-details

## How to setup

### Clone the project

Run the command
 ### `git clone https://github.com/ManjunathHebbar/user-details.git`
 
 Go to project directory
 ### `user-details`
 
 ### Package install

Run the command
 ### `npm install`


## How To Run

Run the command
 ### `npm start`

## Project structure
1. Get a resource
2.List all resources
3.Create new a resource
4.Update a resource
5.Delete a resource
