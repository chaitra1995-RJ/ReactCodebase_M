import React,{Component} from 'react';
import './App.css';
import FormExample from '../src/FormExample.js';
export default class App extends Component {
     
 render(){
    return(
       <div>
         <FormExample/>
       </div>
    );

}

}
