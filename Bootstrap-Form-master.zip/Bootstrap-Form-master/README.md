# Bootstrap-Form

## How to setup

### Clone the project

Run the command
 ### `git clone https://github.com/ManjunathHebbar/Bootstrap-Form.git`
 
 Go to project directory
 ### `Bootstrap-Form`
 
 ### Package install

Run the command
 ### `npm install
