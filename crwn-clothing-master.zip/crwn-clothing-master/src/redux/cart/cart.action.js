import cartActionTypes from './cart.types'

const toggleCartHidden = () => ({
    type:cartActionTypes.TOGGLE_CART_HIDDEN
})

export default toggleCartHidden