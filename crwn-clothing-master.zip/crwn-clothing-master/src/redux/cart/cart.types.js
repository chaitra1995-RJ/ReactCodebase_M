const cartActionTypes = {
    TOGGLE_CART_HIDDEN :'TOGGLE_CART_HIDDEN'
}

export default cartActionTypes;