# display-employee-details

## How to setup

### Clone the project

Run the command
 ### `git clone https://github.com/ManjunathHebbar/display-employee-details.git`

 Go to project directory
 ### `cd display-employee-details`
 
 ### Package install

Run the command
 ### `npm install`


## How To Run

Run the command
 ### `npm start`


